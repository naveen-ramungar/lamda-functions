import requests
import os
import json
from simple_salesforce import Salesforce


def sf_api_call(instance_url,access_token, action, parameters = {}, method = 'get', data = {}):
    headers = {
        'Content-type': 'application/json',
        'Accept-Encoding': 'gzip',
        'Authorization': 'Bearer %s' % access_token
    }
    if method == 'get':
        r = requests.request(method, instance_url+action, headers=headers, params=parameters, timeout=30)
    elif method in ['post', 'patch']:
        r = requests.request(method, instance_url+action, headers=headers, json=data, params=parameters, timeout=10)
    else:
        # other methods not implemented in this example
        raise ValueError('Method should be get or post or patch.')
    print('Debug: API %s call: %s' % (method, r.url) )
    if r.status_code < 300:
        if method=='patch':
            return None
        else:
            return r.json()
    else:
        raise Exception('API error when calling %s : %s' % (r.url, r.content))

def lambda_handler(event, context):
	
	#consumer_key = "3MVG9RHx1QGZ7OsiIaeAv3zzxB8pCKzJFqfgReTbTNukeDCPAJHXZlf4l108g7ESSQ1f0XgaCqIHLHS.qQgw1"
	#consumer_secret = "5141159565366677869"
	#username = "ankush.agarwal@idt.net"
	#password = "dyno@123455rdilEuZZdYyKmyLFVnlBsjI"
	#organizationId = "00Dm000000053a2"
	#access_token_url = 'https://test.salesforce.com/services/oauth2/token'
	
	consumer_key = os.environ['Consumer_Key']
	consumer_secret = os.environ['Consumer_Secret']
	username = os.environ['UserName']
	password = os.environ['Password']
	organizationId = os.environ['OrganizationId']
	access_token_url = os.environ['AccessTokenUrl']
	
	req = None
	data = {
	'grant_type': 'password',
	'client_id': consumer_key,
	'client_secret': consumer_secret,
	'username': username,
	'password': password,
	'organizationId': organizationId
	}
	headers={
				"Content-Type":"application/x-www-form-urlencoded"
			}

	req = requests.post(access_token_url,data=data,headers=headers)
	response = req.json()
	instanceUrl=response['instance_url']
	accessToken=response['access_token']


	print(accessToken)
	print(event['Records'][0]['body'])
	sf = Salesforce(instance_url=response['instance_url'], session_id=response['access_token'])
	records = sf.query("SELECT Id, Name, Email FROM Contact LIMIT 1")
	records = records['records']
	print(records)
	sqsbody = json.loads(event['Records'][0]['body'])
	call = sf_api_call(response['instance_url'],response['access_token'],'/services/apexrest/CreateUpdateProduct/', method="post", data=json.loads(sqsbody['Message']))
	print('result :' + call )
